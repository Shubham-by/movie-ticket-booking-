const express = require("express");
const app = express();
const PORT = 3000;

app.use(express.static("public"));
app.use(express.json());

app.post("/book", (req, res) => {
  const { movie, seats } = req.body;
  console.log(`Booked: ${movie}, Seats: ${seats}`);
  res.json({ success: true, movie, seats });
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});