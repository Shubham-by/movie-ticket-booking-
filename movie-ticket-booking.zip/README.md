# 🎬 Online Movie Ticket Booking System

A simple online movie ticket booking system using **HTML, CSS, JavaScript** and **Node.js (Express)**.

## 🚀 Features

- Select movie from dropdown
- Choose seats visually
- Book multiple seats
- Basic Express backend to handle booking

## 📁 Folder Structure

```
movie-ticket-booking/
├── public/
│   ├── index.html
│   ├── style.css
│   └── script.js
├── server.js
├── package.json
├── .gitignore
└── README.md
```

## 🔧 Installation & Run

1. Clone the repository  
```bash
git clone https://github.com/YOUR_USERNAME/movie-ticket-booking.git
```

2. Navigate to project folder  
```bash
cd movie-ticket-booking
```

3. Install dependencies  
```bash
npm install
```

4. Start the server  
```bash
node server.js
```

5. Open in browser:  
[http://localhost:3000](http://localhost:3000)

## 🛠 Tech Stack

- HTML, CSS, JavaScript
- Node.js + Express

## 💡 Future Scope

- Add login system
- Connect to MongoDB or MySQL
- Admin dashboard for managing movies

---

**Made with ❤️ by Darsh**