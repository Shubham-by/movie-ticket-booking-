const seatContainer = document.getElementById("seatContainer");
const bookBtn = document.getElementById("bookBtn");

for (let i = 1; i <= 30; i++) {
  const seat = document.createElement("div");
  seat.classList.add("seat");
  seat.textContent = i;
  seat.addEventListener("click", () => {
    seat.classList.toggle("selected");
  });
  seatContainer.appendChild(seat);
}

bookBtn.addEventListener("click", () => {
  const selectedSeats = document.querySelectorAll(".seat.selected");
  const seatNumbers = [...selectedSeats].map(seat => seat.textContent);
  const movie = document.getElementById("movie").value;

  fetch("/book", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ movie, seats: seatNumbers })
  })
    .then(res => res.json())
    .then(data => {
      alert(`Booking confirmed for ${movie}, Seats: ${seatNumbers.join(", ")}`);
    });
});